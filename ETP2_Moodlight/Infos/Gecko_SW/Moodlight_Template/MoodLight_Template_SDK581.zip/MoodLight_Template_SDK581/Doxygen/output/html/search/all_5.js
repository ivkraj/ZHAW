var searchData=
[
  ['init_5fxoclocks_44',['INIT_XOclocks',['../globals_8c.html#a6722aa896fe7c90c4e283f433ea7985d',1,'INIT_XOclocks():&#160;globals.c'],['../globals_8h.html#a6722aa896fe7c90c4e283f433ea7985d',1,'INIT_XOclocks():&#160;globals.c']]]
];
