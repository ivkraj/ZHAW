var searchData=
[
  ['globals_2ec_142',['globals.c',['../globals_8c.html',1,'']]],
  ['globals_2eh_143',['globals.h',['../globals_8h.html',1,'']]]
];
