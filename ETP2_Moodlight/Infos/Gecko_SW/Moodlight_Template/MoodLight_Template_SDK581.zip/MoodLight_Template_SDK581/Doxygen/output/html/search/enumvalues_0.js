var searchData=
[
  ['white_230',['WHITE',['../userinterface_8c.html#aa9025a1123214371cc7f6a5bd90da00ea283fc479650da98250635b9c3c0e7e50',1,'userinterface.c']]]
];
