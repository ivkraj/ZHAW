var searchData=
[
  ['touchsliderflag_221',['touchsliderFlag',['../touchslider_8h.html#a480694b73d491af454a7b6d5c8fcddd7',1,'touchsliderFlag():&#160;touchslider.c'],['../touchslider_8c.html#a480694b73d491af454a7b6d5c8fcddd7',1,'touchsliderFlag():&#160;touchslider.c']]],
  ['tx_5fbuf_222',['TX_buf',['../communication_8c.html#a102279f3a9cb069a41479fa509e34926',1,'communication.c']]],
  ['tx_5findex_223',['TX_index',['../communication_8c.html#ae5ec2797d8c8a507838aae2e75ffa0d9',1,'communication.c']]]
];
