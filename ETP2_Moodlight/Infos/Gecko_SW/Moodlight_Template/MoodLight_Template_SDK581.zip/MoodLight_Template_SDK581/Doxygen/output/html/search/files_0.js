var searchData=
[
  ['_5fperipherals_5fcode_5fsnippets_2ec_139',['_peripherals_code_snippets.c',['../__peripherals__code__snippets_8c.html',1,'']]]
];
