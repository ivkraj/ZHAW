var searchData=
[
  ['rx_5fbuf_219',['RX_buf',['../communication_8c.html#a3d589086461401569518fa26d206933f',1,'communication.c']]],
  ['rx_5findex_220',['RX_index',['../communication_8c.html#af5769a387740387f391884e46b1f2ffe',1,'communication.c']]]
];
