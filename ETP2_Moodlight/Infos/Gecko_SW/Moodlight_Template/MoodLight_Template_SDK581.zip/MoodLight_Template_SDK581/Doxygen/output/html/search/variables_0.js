var searchData=
[
  ['com_5frx_5favailable_5fflag_210',['COM_RX_Available_Flag',['../communication_8c.html#accd3ff73e5ec9305a5e3d4541f00bdd1',1,'communication.c']]],
  ['com_5frx_5fdata_211',['COM_RX_Data',['../communication_8c.html#a781fe5dda1107618c2ebf6fba03f6ae3',1,'communication.c']]],
  ['com_5ftx_5fbusy_5fflag_212',['COM_TX_Busy_Flag',['../communication_8c.html#a07dd13c0703f60b232fcae6195869425',1,'communication.c']]],
  ['com_5ftx_5fdata_213',['COM_TX_Data',['../communication_8c.html#ac597da53a336c4b38b67acb6653be917',1,'communication.c']]]
];
