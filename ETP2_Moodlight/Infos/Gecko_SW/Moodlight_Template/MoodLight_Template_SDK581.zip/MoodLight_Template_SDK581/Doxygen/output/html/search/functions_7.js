var searchData=
[
  ['pb_5fdisableirq_187',['PB_DisableIRQ',['../pushbuttons_8h.html#a1524196222e276fa1a922afa5d4bd470',1,'pushbuttons.h']]],
  ['pb_5fenableirq_188',['PB_EnableIRQ',['../pushbuttons_8h.html#a251d22910eea6b84f863fb71255c1876',1,'pushbuttons.h']]],
  ['pb_5finit_189',['PB_Init',['../pushbuttons_8h.html#a4dfda756d68c9bfd03813dbb95459c60',1,'PB_Init(void):&#160;pushbuttons.c'],['../pushbuttons_8c.html#a4dfda756d68c9bfd03813dbb95459c60',1,'PB_Init(void):&#160;pushbuttons.c']]],
  ['pb_5fstatus_190',['PB_Status',['../pushbuttons_8h.html#a4417c1639199f1b247a9419bdcace115',1,'pushbuttons.h']]],
  ['pwr_5facmp_5firqhandler_191',['PWR_ACMP_IRQHandler',['../power_l_e_ds_8h.html#ab02f5d4daeb91b35fbca3abdd48d4999',1,'PWR_ACMP_IRQHandler(void):&#160;powerLEDs.c'],['../power_l_e_ds_8c.html#ab02f5d4daeb91b35fbca3abdd48d4999',1,'PWR_ACMP_IRQHandler(void):&#160;powerLEDs.c']]],
  ['pwr_5fget_5fvalue_192',['PWR_get_value',['../power_l_e_ds_8h.html#a7935805736bd5566e7ee9793f224c53b',1,'PWR_get_value(uint32_t channel):&#160;powerLEDs.c'],['../power_l_e_ds_8c.html#a9eaf20ef6f499180a0936368b666b2f2',1,'PWR_get_value(uint32_t solution):&#160;powerLEDs.c']]],
  ['pwr_5finit_193',['PWR_init',['../power_l_e_ds_8h.html#a2645a97196e2d49cae6faa63771813b8',1,'PWR_init(void):&#160;powerLEDs.c'],['../power_l_e_ds_8c.html#a2645a97196e2d49cae6faa63771813b8',1,'PWR_init(void):&#160;powerLEDs.c']]],
  ['pwr_5fset_5fvalue_194',['PWR_set_value',['../power_l_e_ds_8h.html#a60b01ed2e3f328524c906ad2e1481c88',1,'PWR_set_value(uint32_t channel, int32_t value):&#160;powerLEDs.c'],['../power_l_e_ds_8c.html#a72833630f0c07e3a7d9c82a8d0b11309',1,'PWR_set_value(uint32_t solution, int32_t value):&#160;powerLEDs.c']]]
];
