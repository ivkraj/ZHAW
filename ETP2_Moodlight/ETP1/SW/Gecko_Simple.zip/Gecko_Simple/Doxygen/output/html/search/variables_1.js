var searchData=
[
  ['pb0_5firqflag_183',['PB0_IRQflag',['../pushbuttons_8h.html#af1b029270cc8cbd041ce1987d300de06',1,'PB0_IRQflag():&#160;pushbuttons.c'],['../pushbuttons_8c.html#af1b029270cc8cbd041ce1987d300de06',1,'PB0_IRQflag():&#160;pushbuttons.c']]],
  ['pb1_5firqflag_184',['PB1_IRQflag',['../pushbuttons_8h.html#a84c3faed1ebe7e1676d32a9838b37ef9',1,'PB1_IRQflag():&#160;pushbuttons.c'],['../pushbuttons_8c.html#a84c3faed1ebe7e1676d32a9838b37ef9',1,'PB1_IRQflag():&#160;pushbuttons.c']]],
  ['pwr_5fconversion_5finput_185',['PWR_conversion_input',['../power_l_e_ds_8c.html#afcbe24fe73b278dd9eb3678c369a9674',1,'powerLEDs.c']]],
  ['pwr_5fconversion_5foutput_186',['PWR_conversion_output',['../power_l_e_ds_8c.html#a6bffe685f5851406c5d150c45171ea8f',1,'powerLEDs.c']]],
  ['pwr_5fmaxvalue_187',['PWR_MAXVALUE',['../globals_8c.html#a6a7790147dd904acbad3dac698ab14b4',1,'PWR_MAXVALUE():&#160;globals.c'],['../globals_8h.html#a6a7790147dd904acbad3dac698ab14b4',1,'PWR_MAXVALUE():&#160;globals.h']]],
  ['pwr_5fvalue_188',['PWR_value',['../power_l_e_ds_8c.html#a519b3ac4fc6ea20185001b968c25c5b0',1,'powerLEDs.c']]]
];
