var searchData=
[
  ['pb_5fdisableirq_152',['PB_DisableIRQ',['../pushbuttons_8h.html#a1524196222e276fa1a922afa5d4bd470',1,'pushbuttons.h']]],
  ['pb_5fenableirq_153',['PB_EnableIRQ',['../pushbuttons_8h.html#a251d22910eea6b84f863fb71255c1876',1,'pushbuttons.h']]],
  ['pb_5finit_154',['PB_Init',['../pushbuttons_8h.html#a4dfda756d68c9bfd03813dbb95459c60',1,'PB_Init(void):&#160;pushbuttons.c'],['../pushbuttons_8c.html#a4dfda756d68c9bfd03813dbb95459c60',1,'PB_Init(void):&#160;pushbuttons.c']]],
  ['pb_5fstatus_155',['PB_Status',['../pushbuttons_8h.html#a4417c1639199f1b247a9419bdcace115',1,'pushbuttons.h']]],
  ['pi_5fcontroller_5fadjust_5fcurrent_156',['PI_controller_adjust_current',['../pwm_8c.html#a257b3a17a761f82755146a8569c93776',1,'pwm.c']]],
  ['pwm_5finit_157',['PWM_init',['../pwm_8h.html#a9816c7c730e93dba6a3e231505a40354',1,'PWM_init():&#160;pwm.c'],['../pwm_8c.html#a9816c7c730e93dba6a3e231505a40354',1,'PWM_init():&#160;pwm.c']]],
  ['pwm_5fletimer0_5fchange_158',['PWM_LETIMER0_change',['../pwm_8h.html#ae25492f1000a3d52789ae160c4b860d3',1,'PWM_LETIMER0_change(uint32_t):&#160;pwm.c'],['../pwm_8c.html#aea894c31e6f923b793ad25fb22dc022b',1,'PWM_LETIMER0_change(uint32_t value_compare):&#160;pwm.c']]],
  ['pwm_5fletimer0_5fstart_159',['PWM_LETIMER0_start',['../pwm_8h.html#aced4e013dc7dd7ca2eed6176a24d3c30',1,'PWM_LETIMER0_start():&#160;pwm.c'],['../pwm_8c.html#aced4e013dc7dd7ca2eed6176a24d3c30',1,'PWM_LETIMER0_start():&#160;pwm.c']]],
  ['pwm_5fletimer0_5fstop_160',['PWM_LETIMER0_stop',['../pwm_8h.html#ac5957a7a2abb2a06cd1e75b0c7df6918',1,'PWM_LETIMER0_stop():&#160;pwm.c'],['../pwm_8c.html#ac5957a7a2abb2a06cd1e75b0c7df6918',1,'PWM_LETIMER0_stop():&#160;pwm.c']]],
  ['pwm_5ftimer02_5fstart_161',['PWM_TIMER02_start',['../pwm_8h.html#acda506d622f00f542b1edb66262270d4',1,'PWM_TIMER02_start():&#160;pwm.c'],['../pwm_8c.html#acda506d622f00f542b1edb66262270d4',1,'PWM_TIMER02_start():&#160;pwm.c']]],
  ['pwm_5ftimer02_5fstop_162',['PWM_TIMER02_stop',['../pwm_8h.html#a8f0cf99758967f6001573b645765652c',1,'PWM_TIMER02_stop():&#160;pwm.c'],['../pwm_8c.html#a8f0cf99758967f6001573b645765652c',1,'PWM_TIMER02_stop():&#160;pwm.c']]],
  ['pwm_5ftimer0_5fchange_163',['PWM_TIMER0_change',['../pwm_8h.html#a91e124c305fba3fb8faceb6ba0d3dc46',1,'PWM_TIMER0_change(uint32_t):&#160;pwm.c'],['../pwm_8c.html#aa9dc7ae972928f48363b8cc9e3bd9688',1,'PWM_TIMER0_change(uint32_t compare):&#160;pwm.c']]],
  ['pwr_5fget_5fvalue_164',['PWR_get_value',['../power_l_e_ds_8h.html#a7935805736bd5566e7ee9793f224c53b',1,'PWR_get_value(uint32_t channel):&#160;powerLEDs.c'],['../power_l_e_ds_8c.html#a9eaf20ef6f499180a0936368b666b2f2',1,'PWR_get_value(uint32_t solution):&#160;powerLEDs.c']]],
  ['pwr_5finit_165',['PWR_init',['../power_l_e_ds_8h.html#a2645a97196e2d49cae6faa63771813b8',1,'PWR_init(void):&#160;powerLEDs.c'],['../power_l_e_ds_8c.html#a2645a97196e2d49cae6faa63771813b8',1,'PWR_init(void):&#160;powerLEDs.c']]],
  ['pwr_5fset_5fvalue_166',['PWR_set_value',['../power_l_e_ds_8h.html#a60b01ed2e3f328524c906ad2e1481c88',1,'PWR_set_value(uint32_t channel, int32_t value):&#160;powerLEDs.c'],['../power_l_e_ds_8c.html#a72833630f0c07e3a7d9c82a8d0b11309',1,'PWR_set_value(uint32_t solution, int32_t value):&#160;powerLEDs.c']]]
];
