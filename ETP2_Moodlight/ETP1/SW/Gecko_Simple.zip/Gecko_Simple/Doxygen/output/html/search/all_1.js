var searchData=
[
  ['capsense_5fgetnormalizedval_6',['CAPSENSE_getNormalizedVal',['../touchslider_8c.html#af19a680b4ed145fb46f80f083bdf1b89',1,'touchslider.c']]],
  ['capsense_5fgetpressed_7',['CAPSENSE_getPressed',['../touchslider_8c.html#aca7fb9bf720ccb8962ff993897b10a5b',1,'touchslider.c']]],
  ['capsense_5fgetsliderposition_8',['CAPSENSE_getSliderPosition',['../touchslider_8c.html#a8656b87465aabab5a670b4aeb9988263',1,'touchslider.c']]],
  ['capsense_5fgetslidervalue_9',['CAPSENSE_getSliderValue',['../touchslider_8h.html#a395af876ae382a10fb597db5a358d128',1,'CAPSENSE_getSliderValue(int32_t sliderMin, int32_t sliderMax):&#160;touchslider.c'],['../touchslider_8c.html#a395af876ae382a10fb597db5a358d128',1,'CAPSENSE_getSliderValue(int32_t sliderMin, int32_t sliderMax):&#160;touchslider.c']]],
  ['capsense_5fgetval_10',['CAPSENSE_getVal',['../touchslider_8c.html#a619796be73a1cd8c36f50a5653d730c2',1,'touchslider.c']]],
  ['capsense_5finit_11',['CAPSENSE_Init',['../touchslider_8c.html#a9cc00a748bf5cab4ca2e987e07b17566',1,'touchslider.c']]],
  ['capsense_5fsense_12',['CAPSENSE_Sense',['../touchslider_8c.html#a053d58010d19241662916216a0327ad6',1,'touchslider.c']]]
];
