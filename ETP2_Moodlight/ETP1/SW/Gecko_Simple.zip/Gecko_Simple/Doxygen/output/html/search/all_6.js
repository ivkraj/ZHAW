var searchData=
[
  ['ltostr_30',['ltostr',['../globals_8c.html#aa2888854405a2129b2c533449daef69a',1,'ltostr(int32_t l, char *string):&#160;globals.c'],['../globals_8h.html#aa2888854405a2129b2c533449daef69a',1,'ltostr(int32_t l, char *string):&#160;globals.c']]]
];
