var searchData=
[
  ['freq_5f10k_179',['FREQ_10k',['../globals_8c.html#aa19c3dc64ab8031a954915c39d1475ac',1,'FREQ_10k():&#160;globals.c'],['../globals_8h.html#aa19c3dc64ab8031a954915c39d1475ac',1,'FREQ_10k():&#160;globals.h']]],
  ['freq_5f25k_180',['FREQ_25k',['../globals_8c.html#a181aabd9845b2416c6875a5d08d4036b',1,'FREQ_25k():&#160;globals.c'],['../globals_8h.html#a181aabd9845b2416c6875a5d08d4036b',1,'FREQ_25k():&#160;globals.h']]],
  ['freq_5f400_181',['FREQ_400',['../globals_8c.html#aa109d88cea5ae2d7fd3446d166388ddd',1,'FREQ_400():&#160;globals.c'],['../globals_8h.html#aa109d88cea5ae2d7fd3446d166388ddd',1,'FREQ_400():&#160;globals.h']]],
  ['freq_5f50k_182',['FREQ_50k',['../globals_8c.html#a17abe880b3c92c6d835939cdb7d430c9',1,'FREQ_50k():&#160;globals.c'],['../globals_8h.html#a17abe880b3c92c6d835939cdb7d430c9',1,'FREQ_50k():&#160;globals.h']]]
];
