var searchData=
[
  ['i_28',['I',['../pwm_8c.html#a60ef6e1bcfabb95cfeb300e1d03ce470',1,'pwm.c']]],
  ['init_5fxoclocks_29',['INIT_XOclocks',['../globals_8c.html#a6722aa896fe7c90c4e283f433ea7985d',1,'INIT_XOclocks():&#160;globals.c'],['../globals_8h.html#a6722aa896fe7c90c4e283f433ea7985d',1,'INIT_XOclocks():&#160;globals.c']]]
];
